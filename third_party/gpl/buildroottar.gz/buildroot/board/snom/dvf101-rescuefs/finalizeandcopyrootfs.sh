#!/bin/sh

# Unused, for future usage
BOARD_DIR="$(dirname $0)"

# Remove suid bit from busybox
chmod u-s $TARGET_DIR/bin/busybox

# Create empty sdk directory tree in buildroot/sdk (BASE_DIR points to buildroot/output)
SDK_TARGET_DIR=$(realpath $BASE_DIR/../sdk)
rm -rf "$SDK_TARGET_DIR"
mkdir -p "$SDK_TARGET_DIR/rescuefs"

# Exclude some directories not used or created later by rcS
rsync -aq --delete-before --include=var/www --exclude=etc --exclude=dev --exclude=home --exclude=opt --exclude=media --exclude=mnt --exclude=run --exclude=/tmp/ldconfig --exclude=root --exclude=lib32 --exclude=usr/lib32 --exclude=usr/share/imlib2 --exclude=var/* --exclude=THIS_IS_NOT_YOUR_ROOT_FILESYSTEM "$TARGET_DIR/" "$SDK_TARGET_DIR/rescuefs"
