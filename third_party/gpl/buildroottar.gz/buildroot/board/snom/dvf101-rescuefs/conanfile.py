import os

from conans import ConanFile, tools


class Rescuefs(ConanFile):
    name = "rescuefs_arm_dvf101"
    description = "ARM rescuefs for dvf101 devices"
    settings = "os"
    build_requires = "toolchain_arm_dvf101/77dfe998bb5a5904f46c26317d7ba7f74a5beacb@snom/stable"
    scm = {
        "type": "git",
        "url": "git@git.snom.com:buildroot",
        "revision": "auto"
    }

    def set_version(self):
        """
        Determine package version from current git revision.
        """
        git = tools.Git(folder=self.recipe_folder)
        self.version = git.get_revision()

    def package_info(self):
        self.env_info.RESCUEFS = os.path.join(self.package_folder, "sdk", "rescuefs")

    def build(self):
        self.run("make clean")
        self.run("rm -f .config")
        self.run("make dvf101-rescuefs_defconfig")
        self.run("make")
        self.run("make legal-info")
        # NOTE: we use ConanFile.copy to package these files, this helper function scans all files in the specified
        # source directory. We have some recursive symlinks in output/build, so ConanFile.copy will hang trying to scan
        # it. We need to put this file in a different subdir so that the scan doesn't get stuck:
        self.run("make show-info > output/legal-info/packages-info.json")

    def package(self):
        self.output.info("Copying SDK")
        self.copy("*", src="sdk", dst="sdk", symlinks=True)

        self.output.info("Copying legal-info and packages-info metadata files for SBOM usage")
        self.copy("manifest.csv", src="output/legal-info", dst="metadata")
        self.copy("packages-info.json", src="output/legal-info", dst="metadata")
