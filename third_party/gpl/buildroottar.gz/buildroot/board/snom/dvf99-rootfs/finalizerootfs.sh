#!/bin/sh
if [ ! -z "$1" ]; then
    ROOTFS=$1
    echo "ROOTFS=$ROOTFS"
else
    echo "Usage:"
    echo "  $0 <path too rootfs>"
    exit 1
fi

# Please note that buildroot will create some folders/files after this script is executed. So it might be necessary
# to remove such files in the package() method of the conanfile.py. We currently delete all empty directories there.

# These folders were not copied to rootfs before.
rm -r $ROOTFS/opt
rm -r $ROOTFS/media
rm -r $ROOTFS/mnt
rm -r $ROOTFS/run
rm -r $ROOTFS/var
rm -r $ROOTFS/root
rm -r $ROOTFS/lib32
rm -r $ROOTFS/lib/bash
rm -r $ROOTFS/lib/pkgconfig
rm -r $ROOTFS/usr/lib32

# We need only the static library of reciprocate to build the 3cxsbc project,
# so we remove the unnecessary shared libs from the rootfs
rm -r $ROOTFS/usr/lib/libresip*.so

# The protobuf and grpc packages install libraries that are not needed in Snom code, remove them from target.
rm $ROOTFS/usr/lib/libprotobuf-lite.*
rm $ROOTFS/usr/lib/libgrpc++_*
rm $ROOTFS/usr/lib/libgrpc_*
rm $ROOTFS/usr/lib/libgrpcpp_channelz.*
rm -r $ROOTFS/usr/share/grpc

# Only keep some of the files in etc
mv $ROOTFS/etc $ROOTFS/etc.tmp
mkdir -p $ROOTFS/etc/init.d
cp -a $ROOTFS/etc.tmp/init.d/S30dbus $ROOTFS/etc/init.d
cp -a $ROOTFS/etc.tmp/init.d/S45connman $ROOTFS/etc/init.d
cp -a $ROOTFS/etc.tmp/inittab $ROOTFS/etc
cp -a $ROOTFS/etc.tmp/hostname $ROOTFS/etc
cp -a $ROOTFS/etc.tmp/hosts $ROOTFS/etc
cp -a $ROOTFS/etc.tmp/passwd $ROOTFS/etc
cp -a $ROOTFS/etc.tmp/shadow $ROOTFS/etc
cp -a $ROOTFS/etc.tmp/group $ROOTFS/etc
cp -ar $ROOTFS/etc.tmp/dbus-1 $ROOTFS/etc
cp -ar $ROOTFS/etc.tmp/connman $ROOTFS/etc
# FIXME Packet doesn't compile and is disabled
# cp -ar $ROOTFS/etc.tmp/libnfc* $ROOTFS/etc
rm -r $ROOTFS/etc.tmp

# Modify RPATHs so that the binaries can be executed without setting LD_LIBRARY_PATH
# PER_PACKAGE_DIR must be defined to make fix-rpath work correctly.
PER_PACKAGE_DIR=$BASE_DIR/per-package $BASE_DIR/../support/scripts/fix-rpath host

rsync -aq --delete-before output/build/swupdate-2022.12/tools/swupdate-client "$ROOTFS/usr/bin"
