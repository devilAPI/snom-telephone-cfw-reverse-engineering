set(CMAKE_SYSTEM_NAME Linux)
set(CMAKE_SYSTEM_PROCESSOR arm)

# Setup paths
set(SDK_ROOT ${CMAKE_CURRENT_LIST_DIR}/sdk-buildroot)
set(CMAKE_SYSROOT ${SDK_ROOT}/arm-buildroot-linux-gnueabi/sysroot)
set(CMAKE_PROGRAM_PATH ${SDK_ROOT}/bin)
set(CMAKE_C_COMPILER ${SDK_ROOT}/bin/arm-none-linux-gnueabi-gcc)
set(CMAKE_CXX_COMPILER ${SDK_ROOT}/bin/arm-none-linux-gnueabi-g++)
set(CMAKE_PREFIX_PATH "${CMAKE_SYSROOT}/usr/lib/pkgconfig" ${CMAKE_PREFIX_PATH})

# Only search target (CMAKE_FIND_ROOT_PATH) for libraries etc
set(CMAKE_FIND_ROOT_PATH_MODE_PROGRAM NEVER)
set(CMAKE_FIND_ROOT_PATH_MODE_LIBRARY ONLY)
set(CMAKE_FIND_ROOT_PATH_MODE_INCLUDE ONLY)
set(CMAKE_FIND_ROOT_PATH_MODE_PACKAGE BOTH)
