#!/bin/sh
if [ ! -z "$1" ]; then
    ROOTFS=$1
    echo "ROOTFS=$ROOTFS"
else
    echo "Usage:"
    echo "  $0 <path too rootfs>"
    exit 1
fi

# Remove suid bit from busybox executable. We can't do it in finalizerootfs.sh as the buildroot package explicitly sets
# the suid bit in the fakeroot stage, which is run after the finalizerootfs.sh script.
chmod -s $ROOTFS/bin/busybox
