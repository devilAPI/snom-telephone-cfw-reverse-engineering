#!/bin/sh

# Unused, for future usage
BOARD_DIR="$(dirname $0)"

# Remove suid bit from busybox
chmod u-s $TARGET_DIR/bin/busybox
