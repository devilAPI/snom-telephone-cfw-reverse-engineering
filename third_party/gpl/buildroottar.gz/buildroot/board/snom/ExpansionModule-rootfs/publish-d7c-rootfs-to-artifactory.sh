#!/bin/bash
JFROG=./jfrog
ROOTFS_FILE=output/images/rootfs.tar.bz2
RT_URL=https://snom.jfrog.io/artifactory

export JFROG_CLI_OFFER_CONFIG=false
export JFROG_CLI_BUILD_NAME=rootfs-d7c
export JFROG_CLI_BUILD_NUMBER=$1

if [ ! -f "$JFROG" ]; then
    echo "Couldn't find JFrog CLI - Please download it from https://jfrog.com/getcli/"
    exit 1
fi

if [ -z "$1" ]; then
    echo "Usage $0 <BUILD_ID>"
    exit 1
fi

if [ ! -f "$ROOTFS_FILE" ]; then
    echo "Unable to find rootfs file: $ROOTFS_FILE"
    exit 1
fi


TIMESTAMP=$(date +"%Y%m%d.%H%M%S")
VERSION=1.0
FILEINTEGREV=$VERSION-$TIMESTAMP-$JFROG_CLI_BUILD_NUMBER

$JFROG rt u output/images/rootfs.tar.bz2 rootfs-dev-local/snom/d7c/rootfs-${FILEINTEGREV}.tar.bz2
$JFROG rt bag --config jfrog-git-config.yml
$JFROG rt bp
