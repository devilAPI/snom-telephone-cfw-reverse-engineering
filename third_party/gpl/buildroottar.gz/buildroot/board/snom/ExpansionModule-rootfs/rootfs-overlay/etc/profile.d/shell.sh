export PS1="\u@D7C:\w# "
