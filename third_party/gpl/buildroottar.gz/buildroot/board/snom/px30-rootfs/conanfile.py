import os

from conans import ConanFile, tools


class Sdk(ConanFile):
    name = "sdk_arm_px30"
    description = "ARM SDK for px30 devices"
    settings = "os"

    build_requires = "toolchain_arm_px30/77dfe998bb5a5904f46c26317d7ba7f74a5beacb@snom/stable"

    scm = {
        "type": "git",
        "url": "git@git.snom.com:buildroot",
        "revision": "auto"
    }

    def set_version(self):
        """
        Determine package version from current git revision.
        """
        git = tools.Git(folder=self.recipe_folder)
        self.version = git.get_revision()

    @property
    def toolchain_abi(self):
        return "aarch64-none-linux-gnu"

    def package_info(self):
        bin_folder = os.path.join(self.package_folder, "sdk-buildroot", "bin")
        sysroot = os.path.join(self.package_folder, "sdk-buildroot", "aarch64-buildroot-linux-gnu/sysroot")

        self.env_info.CC = os.path.join(bin_folder, self.toolchain_abi + "-cc")
        self.env_info.CXX = os.path.join(bin_folder, self.toolchain_abi + "-g++")
        self.env_info.CPP = os.path.join(bin_folder, self.toolchain_abi + "-cpp")
        self.env_info.AR = os.path.join(bin_folder, self.toolchain_abi + "-ar")
        self.env_info.RANLIB = os.path.join(bin_folder, self.toolchain_abi + "-ranlib")
        self.env_info.STRIP = os.path.join(bin_folder, self.toolchain_abi + "-strip")
        self.env_info.PKG_CONFIG_PATH = os.path.join(sysroot, "usr/lib/pkgconfig")
        self.env_info.TARGET = self.toolchain_abi

        # Export a path to the rootfs and sysroot
        self.env_info.SYSROOT = sysroot
        self.env_info.ROOTFS = os.path.join(self.package_folder, "rootfs")

        # Include our toolchain when using the CMakeToolchain generator
        self.conf_info["tools.cmake.cmaketoolchain:user_toolchain"] = [os.path.join(self.package_folder,
                                                                                    "px30-toolchain.cmake")]

        # Required to make this package also usable for i386 builds.
        self.cpp_info.builddirs = ["sdk-buildroot"]

    def build(self):
        self.run("make clean")
        self.run("rm -f .config")
        self.run("make px30_rootfs_defconfig")
        self.run("make sdk")
        self.run("make legal-info")
        # NOTE: we use ConanFile.copy to package these files, this helper function scans all files in the specified
        # source directory. We have some recursive symlinks in output/build, so ConanFile.copy will hang trying to scan
        # it. We need to put this file in a different subdir so that the scan doesn't get stuck:
        self.run("make show-info > output/legal-info/packages-info.json")

    def package(self):
        # Uncompress buildroot SDK to package since we want to use it directly from the package.
        self.output.info("Uncompressing buildroot SDK archive to package")
        tools.unzip("output/images/aarch64-buildroot-linux-gnu_sdk-buildroot.tar.gz", destination=self.package_folder)
        tools.rename(os.path.join(self.package_folder, "aarch64-buildroot-linux-gnu_sdk-buildroot"),
                     os.path.join(self.package_folder, "sdk-buildroot"))

        self.output.info("Copying legal-info and packages-info metadata files for SBOM usage")
        self.copy("manifest.csv", src="output/legal-info", dst="metadata")
        self.copy("packages-info.json", src="output/legal-info", dst="metadata")

        self.output.info("Remove the symlinks to the compiler, ccache and the compiler wrapper")
        # These are pointing to where they were during the build.
        # If we build the compiler using buildroot, this can be removed.
        self.run(f"rm {self.package_folder}/sdk-buildroot/bin/aarch64-none-linux-gnu-*")
        self.run(f"rm {self.package_folder}/sdk-buildroot/bin/ccache")
        self.run(f"rm {self.package_folder}/sdk-buildroot/bin/toolchain-wrapper")

        # Retrieve location of the compiler and copy it to the package.
        # If we build the compiler using buildroot, this can be removed.
        toolchain_folder = os.path.join(self.deps_cpp_info["toolchain_arm_px30"].rootpath, "toolchain")
        self.copy(src=toolchain_folder, dst=os.path.join(self.package_folder, "sdk-buildroot"), pattern="*")

        # Copy CMake toolchain file.
        self.copy(src=os.path.join(self.build_folder, "board/snom/px30-rootfs"), dst=self.package_folder,
                  pattern="*.cmake")

        # Uncompress rootfs archive.
        tools.unzip("output/images/rootfs.tar", destination=os.path.join(self.package_folder, "rootfs"))

        # Delete all empty directories in rootfs and sdk to get the same result for a locally built package and
        # a downloaded package. conan 1.x removes all empty directories when a package is compressed for the upload.
        # See issue https://github.com/conan-io/conan/issues/8013 for details. It might get fixed in conan version 2.x.
        self.output.info("Pruning empty directories")
        self.run(f"find {self.package_folder}/rootfs -type d -empty -delete")
        self.run(f"find {self.package_folder}/sdk-buildroot -type d -empty -delete")

        # Delete broken symlinks, these should not be needed when using the output as a SDK anyway.
        self.output.info("Pruning broken symlinks")
        self.run(f"find {self.package_folder} -xtype l -exec rm {{}} +")
