set(CMAKE_SYSTEM_NAME Linux)
set(CMAKE_SYSTEM_PROCESSOR aarch64)

# Setup paths
set(SDK_ROOT ${CMAKE_CURRENT_LIST_DIR}/sdk-buildroot)
set(CMAKE_SYSROOT ${SDK_ROOT}/aarch64-buildroot-linux-gnu/sysroot)
set(CMAKE_PROGRAM_PATH ${SDK_ROOT}/bin)
set(CMAKE_C_COMPILER ${SDK_ROOT}/bin/aarch64-none-linux-gnu-gcc)
set(CMAKE_CXX_COMPILER ${SDK_ROOT}/bin/aarch64-none-linux-gnu-g++)
set(CMAKE_PREFIX_PATH "${CMAKE_SYSROOT}/usr/lib/pkgconfig" ${CMAKE_PREFIX_PATH})

# Only search target (CMAKE_FIND_ROOT_PATH) for libraries etc
set(CMAKE_FIND_ROOT_PATH_MODE_PROGRAM NEVER)
set(CMAKE_FIND_ROOT_PATH_MODE_LIBRARY ONLY)
set(CMAKE_FIND_ROOT_PATH_MODE_INCLUDE ONLY)
set(CMAKE_FIND_ROOT_PATH_MODE_PACKAGE BOTH)
